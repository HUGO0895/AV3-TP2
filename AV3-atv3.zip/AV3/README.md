# cinebridge – microsserviço de recomendação e orquestração (ATV III)

## Requisitos e plataformas
Node.js 20+ e npm. Testado para **Windows 10 ou superior**, **Ubuntu 24.04.03 ou superior** e derivadas do Ubuntu.
Todo acesso a arquivos usa `path`/`os` (sem separadores fixos) e os scripts do `package.json` não dependem de shell.

```
npm install
npm test            # testes (jest)
npm run test:cov    # cobertura
npm run typecheck
```
Para a API: copie `.envExemplo` para `.env`, suba o banco (`docker compose up -d`) e rode `npm start`.

## Padrões estruturais desta atividade
- **Adapter** (`src/adapter`): interfaces `AdaptadorArmazenamento`, `AdaptadorPagamento` e `AdaptadorProfissional`, cada uma com 3 provedores
  (S3/GoogleCloud/Local, Stripe/PagSeguro/PayPal, LinkedIn/Interno) sobre sistemas externos simulados (`simuladores/`).
  `SistemaRecomendacao.configurarAdaptadores(armazenamento, pagamento, profissional)` troca o provedor sem mudar a regra de negócio.
- **Composite** (`src/composite`): `ServicoProjeto`, `ServicoAtomico`, `PacoteServico`. `Projeto.servicoPrincipal`,
  `calcularCustoTotal()` (delega) e `validarEstrutura()` (recursiva: serviços válidos, orçamento e prazos).
- **Decorator** (`src/decorator`): `RecomendadorBase` + `CacheDecorator`, `AuditoriaDecorator`, `CompressaoDecorator`.
  A pilha é montada em tempo de execução por `aplicarDecoradores(base, {decoradores:[...]})` ou, na API, com
  `"parametros": {"decoradores": ["cache","auditoria","compressao"]}`.
